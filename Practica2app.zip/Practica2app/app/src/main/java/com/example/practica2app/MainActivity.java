package com.example.practica2app;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Random;
import java.util.ArrayList;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    //arreglos con los elementos para formar la frase aleatoriamente
    public String personajes[] = {"Con tu crush", "tu amor platónico", "tu actual pareja", "El vago de la esquina", "Con tu cama"};
    public String color_atuendo[] = {"blanco", "negro", "amarillo flourescente con puntos negros", "pijama", "Gris"};
    public String lugar[] = {"Cancun", "Nueva York", "Paris", "basurero", "casa de tu suegra"};
    public String transporte[] = {"avión","yate", "limousina", "patines","burro"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //castear los elementos EditText, Button


        //codificacion de boton
        Button miBotonG = (Button) findViewById(R.id.btnGenerar);
        miBotonG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText miNombre = (EditText) findViewById(R.id.editTextNombre);
                EditText miApellido = (EditText) findViewById(R.id.editTextApellido);
                EditText miEdad = (EditText) findViewById(R.id.editTextEdad);

                Aleatorio(miNombre.getText().toString(), miApellido.getText().toString(), (Integer.parseInt(miEdad.getText().toString())));

            }
        });

        }
        public void Aleatorio(String nombre, String apellido, int edad){ //funcion para generar la posicion aleatoria de los arreglos
                Random rand = new Random();
                int posAlea = rand.nextInt(6);

        Toast.makeText(MainActivity.this, nombre + apellido + " te vas a casar a los " + edad + " con " + personajes[posAlea] +
                " vestid@ de " + color_atuendo[posAlea] + ", te irás de vacaciones a " + lugar[posAlea] +
                    " en " + transporte[posAlea] + "", Toast.LENGTH_LONG).show();
        }

    }

